console.log("prodCheckout1.js");

const db = firebase.firestore();
const storageService = firebase.storage();