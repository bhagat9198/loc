console.log("login.js");

const db = firebase.firestore();
const storageService = firebase.storage();